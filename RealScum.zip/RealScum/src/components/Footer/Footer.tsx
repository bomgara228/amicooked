import styles from './Footer.module.css'
import glords from "../../images/compname.png"
import logo from "../../images/flogo.png"

export const Footer = () => (
    <footer className={styles.footerWrapper}>
        <div className={styles.mainFoot}>
            <div className={styles.rwon}>
                <img className={styles.balancer} src={glords} alt="compname" />
                <img className={styles.balancer} src={logo} alt="logo" />
            </div>
            <h3 className={styles.perek}>Крутое описание и всякая информация</h3>
        </div>
    </footer>
)