import { instance1 } from '../../api';
import style from '../../pages/Main/Main.module.css';
import { useEffect, useState } from 'react';


export const BigTablo = () => {
    const [gamegame,setGamegame] = useState<[]>([])

    interface MainInterface {
        title: string
        price: string
        image1: string
        image2?: string
        image3?: string
        image4?: string
        image5?: string
        image6?: string
    }
    useEffect(() => {
        instance1.get(`https://6634f8309bb0df2359a36312.mockapi.io/api/apps/apps`).then(({ data }) => {
            setGamegame(data)
            
        })
    }, []) 

    useEffect(()=>{
        console.log(gamegame)
    }, [gamegame])
    return (
        <> 
            {
            gamegame.map((item: MainInterface, index: number) => (
                <div className={style.in_a_row}>
                    <img className={style.bigImg} src={item.image1} alt="" />
                    <div className={style.Zaraighter}>
                        <h2>{item.title}</h2>
                        <div className={style.kvadrat}>
                            <img className={style.to_the_right_img} src={item.image3} alt="" />
                            <img className={style.to_the_right_img} src={item.image4} alt="" />
                            <img className={style.to_the_right_img} src={item.image5} alt="" />
                            <img className={style.to_the_right_img} src={item.image6} alt="" />
                        </div>
                        <h3>{item.price}</h3>
                    </div>
                </div>
            ))}
        </>
    )
}