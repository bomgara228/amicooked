import cato from "../../images/cat.gif"
import styles from "./ErrorP.module.css"

export const ErrorP = () =>{
    return(
        <div className={styles.errPage}>
            <h1>Page not found</h1>
            <h2>Error code: 404</h2>
            <img className={styles.miniImg} src={cato} alt="catDance" />
        </div>
    )
}