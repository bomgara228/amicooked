import React from 'react';
import './App.css';
import { BrowserRouter } from 'react-router-dom';
import { store } from '../store';
import { Provider } from 'react-redux';
import { AppRouter } from '../components/AppRouter/AppRouter';
import './App.css';
import {Header} from '../components/Header/Header';
import { Footer } from '../components/Footer/Footer';
import { Loading } from '../components/Loading/Loading';


function App() {

  React.useEffect(()=>{
    document.addEventListener<any>('off', ()=>{
      console.log()
    })
  })

  return (
    <BrowserRouter>
      <React.Suspense fallback={<div><Loading/></div>}>
        <Provider store={store}>
          <Header />
          <AppRouter />
          <Footer/>
        </Provider>
      </React.Suspense>
    </BrowserRouter>
  );
}

export default App;
