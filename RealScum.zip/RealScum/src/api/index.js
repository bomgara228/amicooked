import axios from 'axios';

export const instance1 = axios.create({
    baseURL: 'https://6634f8309bb0df2359a36312.mockapi.io/api/apps/apps',
})

export  function
    NOUDONT() {
        instance1.get(`https://6634f8309bb0df2359a36312.mockapi.io/api/apps/apps`)
        .then(({ data }) => {
            console.log("data", data)
            return data
        })
        .catch(e => console.log(e))
    }


const allGames = fetch('https://6634f8309bb0df2359a36312.mockapi.io/api/apps/apps', {
        method: 'GET',
        headers: { 'content-type': 'application/json' },
    }).then(res => {
        if (res.ok) {
            return res.json();
        }
        // handle error
    }).then(tasks => {
        return (tasks)
    }).catch(error => {
        // handle error
    })
    
export const arrMain = allGames.then(function (result) { return result; })