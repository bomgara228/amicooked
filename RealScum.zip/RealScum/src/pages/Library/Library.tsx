import { Route, Routes } from 'react-router-dom'

const Library = () => (
    <>
        Library
    </>
)
export default Library