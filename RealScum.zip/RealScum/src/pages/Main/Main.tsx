import style from './Main.module.css';
import Larr from "../../images/ArrowL.png"
import Rarr from "../../images/ArrowR.png"
import { BigTablo } from '../../components/BigTablo/midGame';

const Main = () => {
    return (
       
        
        <div className={style.center}>
            <p className={style.tx}>POPULAR AND RECOMMENDED</p>
            <div className={style.stoiRovno}>
                <img src={Larr} alt="strelkal" className={style.streloski} />
                <div className={style.megaBox}>
                <>
                {<BigTablo />}
                </>
                </div>
                <img src={Rarr} alt="strelkar" className={style.streloskir}/>
            </div>
        </div>
    )
}
export default Main